# Enterprise-Architect-VBScript-Library
Library of wrappers and scripts for Enterprise Architect automation

This library contains a bunch of VBScript scripts to be used in Enterprise Architect.
Some may be useful for any context, some have been written to solve a very specific problem and will not be very useful for anyone else

TODO:

- Add a functional wrapper library for EA's API objects

